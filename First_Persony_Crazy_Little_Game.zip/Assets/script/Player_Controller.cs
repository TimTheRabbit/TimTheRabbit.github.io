using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Controller : MonoBehaviour
{
    float total_y = 0;
    public bool moving_enable = true;
    float looking_sens = 500f;
    float move_sens = 10f;
    public Camera cam;
    float gravity = 98f;
    bool is_on_ground = true;
    float y_speed = 0;
    CharacterController controller;
    public int key;
 
    
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        if (moving_enable == true)
        {
            Key_Movement();
            Jump_and_Gravity();
        }
    }

    void LateUpdate()
    {
        if(moving_enable == true)
        {
            Mouse_Look();
        }
            
        
    }

    
    void Jump_and_Gravity()
    {
        if (Input.GetKeyDown("space") && is_on_ground)
        {
            y_speed += 30;
        }
        y_speed -= gravity * Time.deltaTime;
        Vector3 total_y = y_speed * Vector3.up;
        controller.Move(total_y * Time.deltaTime);
        if (controller.collisionFlags == CollisionFlags.Below)
        {
            y_speed = -2f;
            is_on_ground = true;
            
        }
        else
        {
            is_on_ground = false;
            

        }       
        if(controller.collisionFlags == CollisionFlags.Above)
        {
            y_speed = 0;
        }
    }

    void Key_Movement()
    {
        float move_z = Input.GetAxis("Vertical");
        float move_x = Input.GetAxis("Horizontal");
        Vector3 total_m = move_x * transform.right + move_z * transform.forward;
        controller.Move(total_m * Time.deltaTime * move_sens);
        if (Input.GetKeyDown("left shift"))
        {
            move_sens += 20f;
        }
        if(Input.GetKeyUp("left shift"))
        {
            move_sens -= 20f;
        }
    }
    void Mouse_Look()
    {
        float turning_x = Input.GetAxis("Mouse X");
        transform.localEulerAngles += new Vector3(0, turning_x, 0) * Time.deltaTime * looking_sens;

        float turning_y = Input.GetAxis("Mouse Y");
        total_y -= turning_y * Time.deltaTime * looking_sens;
        total_y = Mathf.Clamp(total_y, -70, 70);
        cam.transform.localEulerAngles = new Vector3(total_y, 0, 0);
    }
}
