using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Get_Coin_On_Trigger : MonoBehaviour
{
    public TextMeshPro tmp;
    int coin = 0;
    void OnTriggerEnter(Collider c)
    {
        if (c.gameObject.tag == "coin")
        {
            Destroy(c.gameObject);
            coin += 1;
            print(coin);
            tmp.text = "Coin: " + coin.ToString();
        }
            
    }
}
