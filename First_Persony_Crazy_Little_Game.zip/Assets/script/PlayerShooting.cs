using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShooting : MonoBehaviour
{
    public Transform cam;
    public GameObject bulletPrefab;
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            if(Physics.Raycast(cam.position,cam.forward,out RaycastHit hit))
            {
                GameObject bp = Instantiate(bulletPrefab, hit.point,Quaternion.identity);
                Destroy(bp, 1);
                print(hit.collider.name);
                var health = hit.collider.GetComponent<Helath>();
                if (health != null)
                {
                    health.TakeDamage(20);
                }

            }
            
            
        }
    }
}
