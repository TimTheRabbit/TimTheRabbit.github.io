using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;


public class Open_The_Door : MonoBehaviour
{
    public GameObject turner;
    public Transform target;
    void OnTriggerEnter(Collider c)
    {
        var player_controller = c.gameObject.GetComponent<Player_Controller>();
        if (player_controller  != null && player_controller.key == 4)
        {
            print("turning");
            turner.transform.DOLocalRotate(new Vector3(0, 90, 0), 2f);
            c.transform.position = target.position;
        }
  
    }
}
