using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Helath : MonoBehaviour
{
    public int Hp = 100;
    public void TakeDamage(int amount)
    {
        Hp -= amount;
        if (Hp <= 0)
        {
            Destroy(gameObject);
        }
    }
}
