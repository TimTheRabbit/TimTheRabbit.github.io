using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ragdoll : MonoBehaviour
{
    public Rigidbody midRb;
    void Awake()
    {
        TurnOnRb(false);
    }
    void Update()
    {
        if (Input.GetKeyDown("t"))
        {
            TurnOnRb(true);
        }
    }

    public void TurnOnRb(bool on)
    {
        foreach (var rb in GetComponentsInChildren<Rigidbody>())
        {
            rb.isKinematic = !on;
        }
    }
    void OnCollisionEnter(Collision c)
    {
        TurnOnRb(true);
        var selfCollider = GetComponent<CapsuleCollider>();
        selfCollider.enabled = false;

        var boxRb = c.collider.GetComponent<Rigidbody>();

        midRb.AddForce(boxRb.velocity * 5000, ForceMode.Impulse);
    }
}
