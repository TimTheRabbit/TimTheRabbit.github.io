using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class NPC : MonoBehaviour
{
    public TextMeshPro tmp;
    void OnTriggerEnter(Collider c)
    {
        if (c.gameObject.GetComponent<Player_Controller>() != null)
        {
            var playercontroller = c.gameObject.GetComponent<Player_Controller>();
            playercontroller.key += 1;
            tmp.text = "key: "+ playercontroller.key.ToString() + "(You need four to start the portal)";

            GameObject key = transform.Find("key").gameObject;
            Destroy(key);
            var cps_collider = gameObject.GetComponent<CapsuleCollider>();
            cps_collider.enabled = false;
        }
    }
}
