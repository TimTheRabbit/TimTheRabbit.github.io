using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC_Shower : MonoBehaviour
{
    public GameObject NPC;
    
    void Start()
    {
        NPC.SetActive(false);
    }

    void OnTriggerEnter(Collider c) { 
    
        if(c.GetComponent<Player_Controller>() != null) 
        {
            print("touch_player");
            NPC.SetActive(true);
            Destroy(gameObject);
        }    
    }
}
