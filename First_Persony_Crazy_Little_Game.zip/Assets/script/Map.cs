using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map : MonoBehaviour
{
    public GameObject player;
    public Camera cam;
    void Update()
    {
        if (Input.GetKeyDown("y"))
        {
            transform.SetParent(null);
            cam.fieldOfView = 30;
            transform.position += new Vector3 (0,100,0);
            transform.localEulerAngles = new Vector3(90, 0, 0);
            var look = player.GetComponent<Player_Controller>();
            look.moving_enable = false;
        }
        if (Input.GetKeyUp("y"))
        {
            transform.SetParent(player.transform);
            cam.fieldOfView = 60;
            transform.position = player.transform.position;
            transform.localEulerAngles = player.transform.localEulerAngles;
            var look = player.GetComponent<Player_Controller>();
            look.moving_enable = true;
        }
    }

}
